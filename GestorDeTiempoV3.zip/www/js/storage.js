var c=0;

// api-storage   Local Storage
function writeLocalStorage() {
    /* console.log("pablo");
    window.localStorage.setItem("myKey", "myValue");
    var value = window.localStorage.getItem("myKey");
    console.log(value); */

    var empresa = document.getElementById("empresa").value;
    console.log(empresa);
    
    var actividad = document.getElementById("actividad").value;
    console.log(actividad);
    
    var tipoActividad = document.getElementById("tipoActividad").value;
    console.log(tipoActividad);
    
    var horaInicio = document.getElementById("horaInicio").value;
    console.log(horaInicio);
    
    var fecha = document.getElementById("fecha").value;
    console.log(fecha);
    
    var value = empresa + " - " + actividad + " - " + tipoActividad + " - " + horaInicio + " - " + fecha;
    console.log("Los datos intoducidos son: " + value);
    
    var c = window.localStorage.getItem("contador");
    
    if (!c){
        c=0;
    }

    c++;
    
   window.localStorage.setItem(c,value);
   window.localStorage.setItem("contador", c);
    
    $('#sql-result').html("<strong>" + value + "</strong>");
 
}

function limpiar(){
    var empresa = document.getElementById("empresa");
    var actividad = document.getElementById("actividad");
    var tipoActividad = document.getElementById("tipoActividad");
    var horaInicio = document.getElementById("horaInicio");
    var fecha = document.getElementById("fecha");
    
    empresa.value = "";
    actividad.value = "";
    tipoActividad.value = "";
    horaInicio.value = "";
    fecha.value = "";

}



function readTodayActivity() {
    console.log("Mostrar dia");
    
    var fechaDia = document.getElementById("fechaDia").value;
    console.log(fechaDia);
    
    var contador = window.localStorage.getItem("contador");
    var htmlAll ="";
    for (var i = 1; i <= contador; i++){
        var value = window.localStorage.getItem(i);
        console.log("El valor es: " + value);
        var str = value.split(" - ");
        console.log("valores fecha " + fechaDia);
        if (str[4] == fechaDia){
            var htmlActivity = "<tr><td>" + str[0] + "</td><td>" + str[1] + "</td><td>" + str[2] + "</td><td>" + str[3] + "</td><td>" + str[4] + "</td></tr>";
            htmlAll += htmlActivity;
        }
        
    }
    document.getElementById("today_activity").innerHTML = htmlAll;
}

function readTotalActivity() {
   var contador = window.localStorage.getItem("contador");
    console.log(contador);
    var htmlAll ="";
    for (var i = 1; i <= contador; i++){
        var value = window.localStorage.getItem(i);
        console.log("El valor es: " + value);
        var str = value.split(" - ");
        var htmlActivity = "<tr><td>" + str[0] + "</td><td>" + str[1] + "</td><td>" + str[2] + "</td><td>" + str[3] + "</td><td>" + str[4] + "</td></tr>";
        htmlAll += htmlActivity;
        
    }
    document.getElementById("all_activities").innerHTML = htmlAll;
}

function mostrarIntervalo() {
        console.log("Mostrar intervalo");
        var fechaInicial = document.getElementById("fechaInicial").value;
        console.log(fechaInicial);
    
        var fechaFinal = document.getElementById("fechaFinal").value;
        console.log(fechaFinal);
        
    var contador = window.localStorage.getItem("contador");
    var htmlAll ="";
    for (var i = 1; i <= contador; i++){
        var value = window.localStorage.getItem(i);
        console.log("El valor es: " + value);
        var str = value.split(" - ");
        console.log("valores fecha " + fechaInicial + " "+ fechaFinal);
        if (str[4] >= fechaInicial && str[4] <= fechaFinal){
            var htmlActivity = "<tr><td>" + str[0] + "</td><td>" + str[1] + "</td><td>" + str[2] + "</td><td>" + str[3] + "</td><td>" + str[4] + "</td></tr>";
            htmlAll += htmlActivity;
        }
        
    }
    document.getElementById("tablaDatosIntervalo").innerHTML = htmlAll;
    
}